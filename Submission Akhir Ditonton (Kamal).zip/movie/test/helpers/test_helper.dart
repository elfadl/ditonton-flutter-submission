
import 'package:core/domain/repositories/movie_repository.dart';
import 'package:mockito/annotations.dart';

@GenerateMocks([MovieRepository])
void main(){

}